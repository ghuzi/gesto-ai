/* ==========================================================================
   Gesto AI — frontend logic (vanilla JS, no libraries)
   - Webcam capture: standard canvas.drawImage -> JPEG base64 (no data-url prefix)
   - Streams a frame over WebSocket every ~100ms
   - Protocol: client {"frame": "..."}  ->  server {"gesture", "confidence", "reason"}
   ========================================================================== */

'use strict';

/* ---------- Configuration ---------- */
const WS_URL = 'ws://localhost:8000/ws/predict';
const FRAME_INTERVAL_MS = 100;   // ~10 fps to the inference server
const HISTORY_CAP = 8;           // max entries in the recent-gestures list
const RECONNECT_DELAY_MS = 3000; // auto-retry backoff

/* ---------- DOM references ---------- */
const video = document.getElementById('webcam');
const startBtn = document.getElementById('start-camera');
const stopBtn = document.getElementById('stop-camera');
const speakerBtn = document.getElementById('speaker-btn');
const cameraPlaceholder = document.getElementById('camera-placeholder');
const scanline = document.getElementById('scanline');

const connDot = document.getElementById('conn-dot');
const connText = document.getElementById('conn-text');
const reconnectBtn = document.getElementById('reconnect-btn');

const gestureEl = document.getElementById('gesture-name');
const statusEl = document.getElementById('status-line');
const confidencePct = document.getElementById('confidence-pct');
const progressWrap = document.getElementById('progress-wrap');
const progressFill = document.getElementById('progress-fill');
const historyList = document.getElementById('history-list');
const historyEmpty = document.getElementById('history-empty');

/* ---------- State ---------- */
let ws = null;              // WebSocket instance
let cameraStream = null;    // MediaStream from getUserMedia
let captureTimer = null;    // setInterval handle for frame sending
let reconnectTimer = null;  // setTimeout handle for auto-retry
let demoActive = false;     // camera on AND streaming
let lastLoggedGesture = null;

/* Offscreen canvas used for frame capture (kept outside the capture loop). */
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');

/* --------------------------------------------------------------------------
   CAMERA CAPTURE — the one approved method. Do not change.
   -------------------------------------------------------------------------- */

/** Grab the current video frame and return it as a base64 JPEG string
 *  WITHOUT the "data:image/jpeg;base64," prefix. */
function captureFrameBase64() {
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
}

/* ---------- Camera controls ---------- */

function startCamera() {
  // Disable Start synchronously so a double-click cannot launch two streams
  // and leak the first one; re-enabled in the .catch() path below.
  startBtn.disabled = true;

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    setStatusLine('Camera API unavailable in this browser.');
    startBtn.disabled = false;
    return;
  }

  setStatusLine('Starting camera…');

  navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
    .then(stream => {
      video.srcObject = stream;
      cameraStream = stream;
      cameraPlaceholder.classList.add('is-hidden');
      startBtn.disabled = true;
      stopBtn.disabled = false;
      connectWebSocket(); // ensure server link exists whenever camera runs
    })
    .catch(err => {
      console.error('Camera error:', err);
      setStatusLine('Camera access denied or unavailable.');
      startBtn.disabled = false; // allow retry after failure
    });
}

function stopCamera() {
  stopCaptureLoop();

  // Kill any pending auto-reconnect and detach onclose BEFORE closing the
  // socket, so a stop right after a disconnect cannot trigger a ghost
  // reconnect (and its leaked capture interval).
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  if (ws) {
    ws.onclose = null;
    ws.onerror = null;
    ws.onmessage = null;
    try {
      ws.close();
    } catch (err) {
      // Socket may already be closed — nothing to do.
    }
    ws = null;
  }

  if (cameraStream) {
    cameraStream.getTracks().forEach(t => t.stop());
    cameraStream = null;
  }
  video.srcObject = null;
  demoActive = false;

  cameraPlaceholder.classList.remove('is-hidden');
  scanline.classList.remove('is-scanning');
  startBtn.disabled = false;
  stopBtn.disabled = true;

  setStatusLine('Camera stopped.');
  resetResults();
}

video.addEventListener('playing', () => {
  demoActive = true;
  scanline.classList.add('is-scanning');
  setStatusLine('Camera live — waiting for server…');
});

/* --------------------------------------------------------------------------
   WEBSOCKET — connect, stream frames, handle responses.
   -------------------------------------------------------------------------- */

function connectWebSocket() {
  // Avoid duplicate sockets.
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }

  setConnection('connecting');
  clearTimeout(reconnectTimer);

  try {
    ws = new WebSocket(WS_URL);
  } catch (err) {
    // Invalid URL / immediate failure — fall through to disconnected path.
    setConnection('disconnected');
    return;
  }

  ws.onopen = () => {
    setConnection('connected');
    startCaptureLoop();
  };

  ws.onmessage = (event) => {
    let data;
    try {
      data = JSON.parse(event.data);
    } catch (err) {
      return; // ignore malformed payloads
    }
    handlePrediction(data);
  };

  ws.onerror = () => {
    // onclose always fires after onerror; cleanup happens there.
  };

  ws.onclose = () => {
    setConnection('disconnected');
    stopCaptureLoop();
    // Auto-retry only while the demo is actually running.
    if (demoActive) {
      reconnectTimer = setTimeout(connectWebSocket, RECONNECT_DELAY_MS);
    }
  };
}

/** Send a frame every ~100ms; skip silently when socket/video aren't ready. */
function startCaptureLoop() {
  stopCaptureLoop();
  captureTimer = setInterval(() => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (!demoActive || video.readyState < 2 || !video.videoWidth) return;

    try {
      const frame = captureFrameBase64();
      if (frame) ws.send(JSON.stringify({ frame: frame }));
    } catch (err) {
      // Frame grab hiccup — skip this tick, never crash the loop.
    }
  }, FRAME_INTERVAL_MS);
}

function stopCaptureLoop() {
  if (captureTimer) {
    clearInterval(captureTimer);
    captureTimer = null;
  }
}

/* --------------------------------------------------------------------------
   SERVER RESPONSE HANDLING
   -------------------------------------------------------------------------- */

/** Map server "reason" codes to friendly status text. */
const REASON_TEXT = {
  no_hand: 'No hand detected',
  warming_up: 'Reading gesture…',
  not_ready: 'Model not ready on server',
  below_threshold: 'Reading gesture…',
  decode_failed: 'Reading gesture…'
};

function handlePrediction(data) {
  const { gesture, confidence, reason } = data;

  if (gesture && typeof confidence === 'number') {
    // A gesture was recognized.
    const pct = Math.round(confidence * 100);
    showGesture(gesture, pct);
    setStatusLine(gesture);
    addToHistory(gesture, pct);
  } else if (reason && REASON_TEXT[reason]) {
    // No recognition yet — show the mapped reason, decay the bar.
    setStatusLine(REASON_TEXT[reason]);
    if (reason === 'no_hand' || reason === 'decode_failed') {
      gestureEl.textContent = '—';
      updateConfidence(0);
    }
  }
}

function showGesture(name, pct) {
  if (gestureEl.textContent !== name) {
    gestureEl.textContent = name;
    // Retrigger the pop animation.
    gestureEl.classList.remove('flash');
    void gestureEl.offsetWidth;
    gestureEl.classList.add('flash');
  }
  updateConfidence(pct);
}

function updateConfidence(pct) {
  const clamped = Math.max(0, Math.min(100, pct));
  confidencePct.textContent = clamped + '%';
  progressFill.style.width = clamped + '%';
  progressWrap.setAttribute('aria-valuenow', String(clamped));
}

function setStatusLine(text) {
  statusEl.textContent = text;
}

function resetResults() {
  gestureEl.textContent = '—';
  setStatusLine('Waiting for camera…');
  updateConfidence(0);
}

/* ---------- Recent gestures history ---------- */

function addToHistory(name, pct) {
  // Skip consecutive duplicates to avoid spamming the list.
  if (name === lastLoggedGesture) return;
  lastLoggedGesture = name;

  if (historyEmpty && historyEmpty.parentNode === historyList) {
    historyList.removeChild(historyEmpty);
  }

  const li = document.createElement('li');

  const nameSpan = document.createElement('span');
  nameSpan.className = 'h-name';
  nameSpan.textContent = name;

  const timeSpan = document.createElement('span');
  timeSpan.className = 'h-time';
  timeSpan.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const confSpan = document.createElement('span');
  confSpan.className = 'h-conf';
  confSpan.textContent = pct + '%';

  li.append(nameSpan, timeSpan, confSpan);
  historyList.prepend(li);

  // Cap the list length.
  while (historyList.children.length > HISTORY_CAP) {
    historyList.removeChild(historyList.lastChild);
  }
}

/* ---------- Connection status UI ---------- */

function setConnection(state) {
  connDot.className = 'conn-dot'; // reset modifier classes
  reconnectBtn.hidden = true;

  if (state === 'connected') {
    connDot.classList.add('is-connected');
    connText.textContent = 'Connected to server';
  } else if (state === 'connecting') {
    connDot.classList.add('is-connecting');
    connText.textContent = 'Connecting…';
  } else {
    connDot.classList.add('is-disconnected');
    connText.textContent = 'Server disconnected';
    reconnectBtn.hidden = false;
  }
}

reconnectBtn.addEventListener('click', () => {
  clearTimeout(reconnectTimer);
  connectWebSocket();
});

/* ---------- Speaker button (Urdu TTS placeholder — UI only) ---------- */

speakerBtn.addEventListener('click', () => {
  const active = speakerBtn.classList.toggle('is-active');
  speakerBtn.setAttribute('aria-pressed', String(active));
  // Placeholder: no real TTS yet. Active state + tooltip are the wire-up.
});

/* ---------- Start / Stop wiring ---------- */

startBtn.addEventListener('click', startCamera);
stopBtn.addEventListener('click', stopCamera);

// Attempt a background connection on load so status is honest before demo.
connectWebSocket();

/* ---------- Scroll reveal for sections ---------- */

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.panel, .step, .member, .badge, .about__text, .badges')
  .forEach(el => {
    el.classList.add('scroll-reveal');
    revealObserver.observe(el);
  });

/* ---------- Smooth-scroll focus management for in-page anchors ---------- */

document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', (e) => {
    const target = document.querySelector(link.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    // Move keyboard focus to the section for accessibility.
    target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
  });
});
